# MoS Reader (Android wrapper)

A minimal Android app that wraps The Machine of Satan HTML reader in a
WebView and injects `window.NativeTTS`, a bridge to Android's own
TextToSpeech engine. The system engine reports the exact character range of
every word as it speaks (`onRangeStart`), the callback mobile browsers never
deliver, so inside this app the word highlight is event-exact while whole
passages are spoken in one piece with natural sentence prosody. The same
HTML file still works unchanged in any browser.

## Build (once, ~10 minutes)

1. Install Android Studio (any recent version). Open this folder
   (`MoS-Reader-Android`) and let Gradle sync.
2. On your phone: Settings > About > tap Build number 7 times, then enable
   USB debugging in Developer options. Plug the phone in.
3. Press Run. The app installs and launches.

## Use

- First launch shows a file picker: choose `The_Machine_of_Satan-24.html`
  (from Downloads or wherever you keep it). The choice is remembered.
- Or open the HTML from your file manager with "Open with > MoS Reader".
- The voice menu lists the system TTS voices. For the best voices install
  or update "Speech Services by Google" and its voice data; the app prefers
  the Google engine and falls back to the system default (Samsung TTS also
  reports word ranges on current versions).
- Screen stays on while playing; the Sync trim and bookmarks work as in
  the browser and are remembered inside the app.

## Notes

- minSdk 26 (Android 8.0), target 35. No network permission: the app reads
  only the file you pick and talks only to the on-device speech engine.
- To update the book, just open the newer HTML file the same way.

## No computer? Build it from your phone

GitHub will build the APK for you in the cloud, free, entirely from the
phone's browser:

1. Create a free account at github.com, then tap + and "New repository"
   (private is fine). 
2. In the repo: "Add file" > "Upload files" > upload `MoS-Reader-Android.zip`
   (the zip itself, one file). Commit.
3. "Add file" > "Create new file". Name it exactly
   `.github/workflows/build-apk.yml` and paste in the contents of the
   `build-apk.yml` file provided alongside the zip. Commit.
4. Open the "Actions" tab. A "Build APK" run starts on its own (or tap it
   and "Run workflow"). Wait ~3 minutes for the green check.
5. Open the finished run, download the "MoS-Reader-APK" artifact, extract
   the zip in your Files app, and tap `app-debug.apk` to install. Android
   will ask you to allow installs from that app once.

Then open MoS Reader, pick The_Machine_of_Satan-24.html, and it speaks with
native word-exact highlighting.
