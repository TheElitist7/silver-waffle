package com.darkkrey.mosreader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * A full-screen WebView around the reader HTML, with NativeTts injected as
 * window.NativeTTS before the page loads. Open the book from the launcher
 * (a picker appears once and the choice is remembered) or from any file
 * manager via "Open with". The same HTML file runs unchanged in a browser;
 * inside this app it detects the bridge and switches to native speech.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private var bridge: NativeTts? = null
    private val prefs by lazy { getSharedPreferences("mos", MODE_PRIVATE) }

    private val picker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            prefs.edit().putString("book", uri.toString()).apply()
            loadBook(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        val s: WebSettings = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true          // bookmarks, calibration, sync trim
        s.allowFileAccess = true
        s.mediaPlaybackRequiresUserGesture = false
        s.textZoom = 100

        bridge = NativeTts(
            this, web,
            onReady = {
                // Engine voices may arrive after page load: refresh the menu.
                web.evaluateJavascript(
                    "typeof loadVoices==='function'&&loadVoices()", null)
            },
            keepScreenOn = { on ->
                if (on) window.addFlags(
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            })
        web.addJavascriptInterface(bridge!!, "NativeTTS")

        val fromIntent = intent?.data
        val saved = prefs.getString("book", null)?.let { Uri.parse(it) }
        when {
            fromIntent != null -> {
                prefs.edit().putString("book", fromIntent.toString()).apply()
                loadBook(fromIntent)
            }
            saved != null -> loadBook(saved)
            else -> picker.launch(arrayOf("text/html"))
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.data?.let {
            prefs.edit().putString("book", it.toString()).apply()
            loadBook(it)
        }
    }

    private fun loadBook(uri: Uri) {
        val html = try {
            contentResolver.openInputStream(uri)?.bufferedReader()
                ?.use { it.readText() }
        } catch (_: Exception) { null }
        if (html == null) { picker.launch(arrayOf("text/html")); return }
        // A stable https base gives localStorage one consistent origin.
        web.loadDataWithBaseURL(
            "https://mos.local/", html, "text/html", "utf-8", null)
    }

    override fun onDestroy() {
        bridge?.shutdown()
        super.onDestroy()
    }
}
