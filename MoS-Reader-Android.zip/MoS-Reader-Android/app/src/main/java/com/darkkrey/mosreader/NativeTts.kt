package com.darkkrey.mosreader

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * The bridge the reader page detects as window.NativeTTS.
 *
 * The whole reason this app exists: Android's own TextToSpeech reports the
 * exact character range of every word as it is spoken (onRangeStart), the
 * callback the mobile browser never delivers. The page feeds those events
 * into the same clock it uses everywhere, and the highlight becomes
 * event-exact while whole units are spoken in one piece, so the prosody is
 * the engine's natural sentence reading with no artificial seams.
 */
class NativeTts(
    private val context: Context,
    private val webView: WebView,
    private val onReady: () -> Unit,
    private val keepScreenOn: (Boolean) -> Unit
) {
    @Volatile private var ready = false
    private var tts: TextToSpeech? = null

    init { create("com.google.android.tts", allowFallback = true) }

    /** Prefer Google's engine (reliable onRangeStart); fall back to default. */
    private fun create(engine: String?, allowFallback: Boolean) {
        tts = if (engine != null)
            TextToSpeech(context, { status -> onInit(status, allowFallback) }, engine)
        else
            TextToSpeech(context) { status -> onInit(status, false) }
    }

    private fun onInit(status: Int, allowFallback: Boolean) {
        if (status != TextToSpeech.SUCCESS) {
            if (allowFallback) { tts?.shutdown(); create(null, false) }
            return
        }
        tts?.language = Locale.US
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) = js("s", id)
            override fun onRangeStart(id: String?, start: Int, end: Int, frame: Int) =
                js("b", id, start)
            override fun onDone(id: String?) = js("d", id)
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) = js("e", id)
            override fun onError(id: String?, code: Int) = js("e", id)
        })
        ready = true
        webView.post { onReady() }
    }

    /** Callbacks arrive on a binder thread; evaluateJavascript needs main. */
    private fun js(fn: String, id: String?, arg: Int? = null) {
        val safe = (id ?: "").replace("\\", "").replace("'", "")
        val call = "window.NativeCB&&NativeCB.$fn('" + safe + "'" +
                (if (arg != null) ",$arg" else "") + ")"
        webView.post { webView.evaluateJavascript(call, null) }
    }

    @JavascriptInterface fun isReady(): Boolean = ready

    @JavascriptInterface fun speak(id: String, text: String) {
        val t = tts ?: return
        val max = TextToSpeech.getMaxSpeechInputLength()
        val body = if (text.length > max) text.substring(0, max - 1) else text
        t.speak(body, TextToSpeech.QUEUE_ADD, Bundle(), id)
    }

    @JavascriptInterface fun stop() { tts?.stop() }

    @JavascriptInterface fun setRate(rate: Float) { tts?.setSpeechRate(rate) }

    @JavascriptInterface fun setVoice(name: String) {
        val t = tts ?: return
        val v = t.voices?.firstOrNull { it.name == name } ?: return
        t.voice = v
    }

    @JavascriptInterface fun getVoices(): String {
        val t = tts ?: return "[]"
        val def = t.defaultVoice?.name
        val arr = JSONArray()
        val vs = t.voices ?: return "[]"
        vs.sortedBy { it.name }.forEach { v ->
            arr.put(JSONObject()
                .put("n", v.name)
                .put("l", v.locale.toLanguageTag())
                .put("def", v.name == def))
        }
        return arr.toString()
    }

    @JavascriptInterface fun keepAwake(on: Boolean) {
        webView.post { keepScreenOn(on) }
    }

    fun shutdown() { tts?.stop(); tts?.shutdown() }
}
